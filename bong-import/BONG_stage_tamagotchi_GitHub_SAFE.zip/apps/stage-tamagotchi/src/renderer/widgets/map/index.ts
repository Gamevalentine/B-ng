export { default as Map } from './components/Map.vue'
