<template>
  <slot />
</template>
