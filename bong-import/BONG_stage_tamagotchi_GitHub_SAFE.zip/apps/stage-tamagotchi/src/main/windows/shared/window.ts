import type { createContext } from '@moeru/eventa/adapters/electron/main'
import type { ResizeDirection } from '@proj-airi/electron-eventa'
import type { BrowserWindow, BrowserWindowConstructorOptions, Rectangle } from 'electron'

import type { I18n } from '../../libs/i18n'
import type { ServerChannel } from '../../services/airi/channel-server'

import { isRendererUnavailable } from '@proj-airi/electron-vueuse/main'
import { shell } from 'electron'
import { isMacOS, isWindows } from 'std-env'

import { createServerChannelService } from '../../services/airi/channel-server'
import { createI18nService } from '../../services/airi/i18n'
import { createAppService, createDesktopActivityService, createPowerMonitorService, createScreenService, createSystemPreferencesService, createWindowService } from '../../services/electron'

export function toggleWindowShow(window?: BrowserWindow | null): void {
  if (!window) {
    return
  }
  if (isRendererUnavailable(window)) {
    return
  }

  if (window?.isMinimized()) {
    window?.restore()
  }

  window?.show()
  window?.focus()
}

export function transparentWindowConfig(): BrowserWindowConstructorOptions {
  return {
    frame: false,
    titleBarStyle: isMacOS ? 'hidden' : undefined,
    transparent: true,
    hasShadow: false,
  }
}

/**
 * Blocks renderer navigation while allowing safe links to open in the system browser.
 *
 * Use when:
 * - Creating an Electron window that receives the shared privileged preload
 *
 * Expects:
 * - The window loads only AIRI-controlled renderer content
 *
 * Returns:
 * - Nothing; installs navigation and popup guards on the window's web contents
 */
export function protectPrivilegedWindowNavigation(window: BrowserWindow): void {
  function openSafeExternalUrl(rawUrl: string): void {
    try {
      const url = new URL(rawUrl)
      if (url.protocol === 'http:' || url.protocol === 'https:' || url.protocol === 'mailto:')
        void shell.openExternal(url.toString())
    }
    catch {
      // Ignore malformed navigation targets.
    }
  }

  window.webContents.setWindowOpenHandler((details) => {
    openSafeExternalUrl(details.url)
    return { action: 'deny' }
  })
  window.webContents.on('will-navigate', (event, navigationUrl) => {
    // Renderer-initiated reloads keep the exact current URL in both packaged
    // (`file:`) and Vite (`http:`) builds. Let those through without widening
    // navigation to other local files or development-server paths.
    if (navigationUrl === window.webContents.getURL())
      return

    event.preventDefault()
    openSafeExternalUrl(navigationUrl)
  })
}

export function blurryWindowConfig(): BrowserWindowConstructorOptions {
  return {
    vibrancy: 'hud',
    backgroundMaterial: 'acrylic',
  }
}

export function spotlightLikeWindowConfig(): BrowserWindowConstructorOptions {
  return {
    ...blurryWindowConfig(),
    titleBarStyle: isMacOS ? 'hidden' : undefined,
  }
}

/**
 * Sets the window always-on-top level according to the host platform.
 *
 * macOS and Windows support the screen-saver level and relative level layering,
 * while Linux (X11/Wayland) works reliably with standard always-on-top.
 */
export function setWindowAlwaysOnTop(
  window: Pick<BrowserWindow, 'setAlwaysOnTop'>,
  flag: boolean,
  relativeLevel = 1,
): void {
  if (!flag) {
    window.setAlwaysOnTop(false)
    return
  }

  if (isMacOS || isWindows) {
    window.setAlwaysOnTop(true, 'screen-saver', relativeLevel)
    return
  }

  window.setAlwaysOnTop(true)
}

interface ResizeByDeltaOptions {
  deltaX: number
  deltaY: number
  direction: ResizeDirection
  minWidth?: number
  minHeight?: number
}

/**
 * Bounds after an edge or corner drag of `direction` by the cursor movement.
 * The edges opposite `direction` stay in place, and the size stops at the
 * minimum instead of moving those edges.
 *
 * @example
 * resizeBoundsByDelta({ x: 100, y: 100, width: 400, height: 500 }, { deltaX: -20, deltaY: -30, direction: 'nw' })
 * // => { x: 80, y: 70, width: 420, height: 530 }
 */
export function resizeBoundsByDelta(bounds: Rectangle, params: ResizeByDeltaOptions): Rectangle {
  const minWidth = params.minWidth ?? 100
  const minHeight = params.minHeight ?? 200

  let { x, y, width, height } = bounds

  if (params.direction.includes('e')) {
    width = Math.max(minWidth, width + params.deltaX)
  }
  if (params.direction.includes('w')) {
    const newWidth = Math.max(minWidth, width - params.deltaX)
    if (newWidth !== width) {
      x = x + (width - newWidth)
      width = newWidth
    }
  }

  if (params.direction.includes('s')) {
    height = Math.max(minHeight, height + params.deltaY)
  }
  if (params.direction.includes('n')) {
    const newHeight = Math.max(minHeight, height - params.deltaY)
    if (newHeight !== height) {
      y = y + (height - newHeight)
      height = newHeight
    }
  }

  return { x, y, width, height }
}

export function resizeWindowByDelta(params: ResizeByDeltaOptions & { window: BrowserWindow }): void {
  params.window.setBounds(resizeBoundsByDelta(params.window.getBounds(), params))
}

export async function setupBaseWindowElectronInvokes(params: {
  context: ReturnType<typeof createContext>['context']
  window: BrowserWindow
  serverChannel: ServerChannel
  i18n: I18n
}) {
  createScreenService({ context: params.context, window: params.window })
  createWindowService({ context: params.context, window: params.window })
  createDesktopActivityService({ context: params.context, window: params.window })
  createAppService({ context: params.context, window: params.window })
  createPowerMonitorService({ context: params.context, window: params.window })
  createSystemPreferencesService({ context: params.context, window: params.window })

  await createI18nService({ context: params.context, window: params.window, i18n: params.i18n })

  createServerChannelService({ serverChannel: params.serverChannel })
}
